package br.com.targettrust.locadora.entidades;


public class Funcionario extends Usuario{
	private String matricula;

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	

}
